create function random_string(integer) returns text
  language sql
as
$$
select array_to_string(array(select substring('0123456789-abcdefghijklmnopqrstuvwxyz' FROM (ceil(random()*62))::int FOR 1) FROM generate_series(1, $1)), '');
$$;

alter function random_string(integer) owner to root;

